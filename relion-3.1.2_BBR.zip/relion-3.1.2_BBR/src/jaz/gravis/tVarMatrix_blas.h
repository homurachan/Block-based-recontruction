#ifndef __LIBGRAVIS_T_VAR_MATRIX_BLAS_H__
#define __LIBGRAVIS_T_VAR_MATRIX_BLAS_H__
#include "tVarMatrix.h"

namespace gravis
{
  namespace matrix
  {
    // Single and double implementations
#define __GRAVIS__MATRIX__BLAS__DATATYPE__SINGLE__
#include "tVarMatrix_blas.hxx"
#undef __GRAVIS__MATRIX__BLAS__DATATYPE__SINGLE__
#define __GRAVIS__MATRIX__BLAS__DATATYPE__DOUBLE__
#include "tVarMatrix_blas.hxx"
#undef __GRAVIS__MATRIX__BLAS__DATATYPE__DOUBLE__
  }
}

#endif
