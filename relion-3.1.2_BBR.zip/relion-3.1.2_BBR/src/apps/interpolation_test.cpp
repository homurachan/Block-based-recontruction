#include <src/jaz/interpolation.h>

int main(int argc, char *argv[])
{
	Interpolation::test2D();

	return RELION_EXIT_SUCCESS;	
}
